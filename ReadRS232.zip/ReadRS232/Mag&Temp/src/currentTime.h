void CurrentTime(char *strname,int strlen);

