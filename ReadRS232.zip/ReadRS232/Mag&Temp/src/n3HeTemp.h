void ReadTemp(Serial &temp, int *zone,double field,long loop);

