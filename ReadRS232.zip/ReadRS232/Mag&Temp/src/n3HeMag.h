

int SignOn(bool &signon);
int ReadField(FluxGate &p,double *fValue);
void signalHandler( int signum );
