

int SignOn(bool &signon);
void ReadField(FluxGate &p,double *fValue);
void signalHandler( int signum );
