#define SLEEP_TIME 200000
#define PORT "/dev/ttyUSB0"
#define WAKE_UP_BAUD 300
#define BAUD 9600
#define DATA_FILE "/home/daq/ReadRS232/ReadMag/magData.txt" 
