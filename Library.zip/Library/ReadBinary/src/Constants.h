#define DATA_FILE "data/000"
#define NCHAN 64
