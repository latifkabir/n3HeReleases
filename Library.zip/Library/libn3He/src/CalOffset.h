// The Dynamic Offset Calculation to go around issues with data stream for first few events from the DAQ

int CalOffset(const char* filename,int module);
