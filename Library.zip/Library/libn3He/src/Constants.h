#define DATA_PATH "/home/siplu/GIT/MyAnalysis/SampleData/3.libn3He/"

#define DAQ21_LEAF "h21[48]/I:d21[49][48]/I"
#define DAQ22_LEAF "h22[48]/I:d22[49][48]/I"
#define DAQ23_LEAF "h23[48]/I:d23[49][48]/I"
#define DAQ24_LEAF "h24[48]/I:d24[49][48]/I"
#define DAQ30_LEAF "h30[8]/I:d30[1624][8]/I"
