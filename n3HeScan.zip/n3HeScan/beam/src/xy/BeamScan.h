int BeamScan(void);
int CustomMove();

