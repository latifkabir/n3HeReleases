//#define DATA_FILE_CLEAN "/home/daq/DATA/run-%ddata-%d"
#define NCHAN 8
//#define ES_MAGIC 0xaa55f154
//#define ADC_TO_VOLT 4.6566e-9

