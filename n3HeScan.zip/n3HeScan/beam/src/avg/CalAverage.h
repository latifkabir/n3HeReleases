

double CalAverage(int run,int module,int ch);
