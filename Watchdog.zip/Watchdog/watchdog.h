#define TRANS_COMMAND "/home/siplu/GIT/n3He_Soft/Github/Watchdog/transferFile.sh %d %d"
#define WATCHDOG_PATH "/home/siplu/GIT/n3He_Soft/Github/Watchdog/"
