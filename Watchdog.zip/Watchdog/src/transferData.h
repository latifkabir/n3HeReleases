int TransferData(int rNumber,int lastTransferred);
