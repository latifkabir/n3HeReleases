//-----------------Send text alert if any param goes out of range----------

int TextAlert(int run_number,int last_run,double mag, double* temp, bool *alert_enabled);
