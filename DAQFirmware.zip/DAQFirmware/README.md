This directory contain DAQ Firmware related Software update provided by the manufacturer:

1. FPGA : The FPGA Updates by manufacturer


2. CSS  : Latest CSS extension for the DAQ Control


3. CHeckSum : Code to calculate CRC Checksum

4. Config : The default start up configuration for each DAQ Module + Our own customization. 
 					
										Last Updated on 9/22/14
                                                                                 -Latiful Kabir
