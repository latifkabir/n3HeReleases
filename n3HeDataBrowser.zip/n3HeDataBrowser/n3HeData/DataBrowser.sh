#!/bin/bash
. /home/siplu/TOOLS/ROOT/root-5.34/bin/thisroot.sh
. $HOME/GIT/n3He_Soft/Github/n3HeDataBrowser/libn3He/bin/thisn3He.sh
$HOME/GIT/n3He_Soft/Github/n3HeDataBrowser/n3HeData/n3HeData
