#!/bin/bash
. /usr/local/bin/thisroot.sh
. /home/daq/Library/libn3He/bin/thisn3He.sh
/home/daq/DataBrowser/n3HeData
