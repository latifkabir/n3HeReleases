PlotCh
======
This script can plot ADC count vs entry number for specied channel starting from specified point. 
This is purely C++ script but the final plot is shown thgrough ROOT.

Steps
----
* Do `make`
* Usage: ./plot RUN_NUMBER MODULE CHANNEL

Note: Currently it is NOT compatible with ROOT6

										Last Updated on 11/25/14
                                                                                 -Latiful Kabir
