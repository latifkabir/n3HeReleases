PlotCh
======
This script can make histogram of a given run for specified channel.
This is purely C++ script but the final histogram is shown thgrough ROOT.

Steps
----
* Do `make`
* Usage: ./histo RUN_NUMBER MODULE CHANNEL

Note: Currently it is NOT compatible with ROOT6

									Last Updated on 11/23/14
                                                                                 -Latiful Kabir
