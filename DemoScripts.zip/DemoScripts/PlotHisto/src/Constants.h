#define DATA_FILE "/home/daq/DATA/run-%ddata-%d"
#define NCHAN 48
#define ES_MAGIC 0xaa55f154
#define ADC_TO_VOLT 4.6566e-9

