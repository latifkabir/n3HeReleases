#define DATA_FILE "/home/daq/DATA/Peter_data/shot%d"
#define NCHAN 48
#define ES_MAGIC1 0xaa55f154
#define ES_MAGIC2 0xaa55f15f
#define ADC_TO_VOLT 4.6566e-9

