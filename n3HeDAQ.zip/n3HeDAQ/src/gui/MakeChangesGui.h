//The Ncurses gui to select DAQ Config
//Author: Latiful Kabir
//Date:11.9.14
//Version:1.0

int Resolution(int module);
int Mode(int module);
int Averaging(int module);
int Decimation(int module);
int Length(int module);
int Rate(int module);
int ChangeRunLength();
  
 
 
 
