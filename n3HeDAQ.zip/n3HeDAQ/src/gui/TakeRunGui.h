//The Ncurses gui to take the run.
//Author: Latiful Kabir
//Date:11.9.14
//Version:1.0


#include"Constants.h"
int RunSingleGui(int module=MODULE,int runlength=RUN_LENGTH,int runNumber=RUN_NUMBER);
int RunAllGui (int runlength=RUN_LENGTH,int runNumber=RUN_NUMBER);

