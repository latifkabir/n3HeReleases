//Header for Ncurses Menu for GUI mode
//Author: Latiful Kabir
//Date:11.9.14
//Version:1.0

//void menu_positionnement();
//int test();
//int test2();
//void test3();
int Menu(void);



