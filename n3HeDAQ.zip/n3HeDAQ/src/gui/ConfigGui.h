int ConfigGui();
int CustomConfig(int module);
int CustomDaq();
int RunLength();  
  
