//This program Processes data file to throw away unused channels.
//Author: Latiful Kabir
//Date: 01/19/15

int ProcessData(int run,int module,bool gui_mode); 
