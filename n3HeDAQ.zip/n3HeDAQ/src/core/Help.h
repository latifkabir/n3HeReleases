//Header for the program to Show Help Session
//Author: Latiful Kabir
//Date:08.15.14
//Version:1.0


//Default help instruction

void DefaultIns();
void Title();
void Instruction();
void Config();

