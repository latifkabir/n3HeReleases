//Header for Changing DAQ Configuration.
//Author: Latiful Kabir
//Date:11.11.14
//Version:1.0

int ChangeConfig(void);
int MakeChange(int module,char *command,int site);
int ChangeRate(int module,int rate);
int ChangeMode(int module,int mode);
int ChangeLength(int module,int length);
int ChangeRes(int module,int res);
int ChangeAveraging(int module,int avg);
int ChangeAveraging(int module,int avg);
int ChangeDecimation(int module,int dec);
int ChangeConfig(void);

