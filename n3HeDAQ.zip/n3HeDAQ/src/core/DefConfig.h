//Changing DAQ Configuration.
//Author: Latiful Kabir
//Date:11.23.14
//Version:1.0

int n3heDefault(int module);
int ContinuousMode(int module);

