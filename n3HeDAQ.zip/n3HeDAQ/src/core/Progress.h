void printProgBar( int percent );
